﻿namespace Freelancer_Anne
{
    partial class TelaDesbridamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSair = new System.Windows.Forms.Button();
            this.btnDesbridamento = new System.Windows.Forms.Button();
            this.btnLesao = new System.Windows.Forms.Button();
            this.btnNeuropatia = new System.Windows.Forms.Button();
            this.btnEstomia = new System.Windows.Forms.Button();
            this.btnInicio = new System.Windows.Forms.Button();
            this.tbTexto = new System.Windows.Forms.TextBox();
            this.btnMedicacoes = new System.Windows.Forms.Button();
            this.btnTratamentos = new System.Windows.Forms.Button();
            this.btnCausas = new System.Windows.Forms.Button();
            this.btnDefinicao = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.Red;
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSair.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.Color.White;
            this.btnSair.Location = new System.Drawing.Point(600, -2);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(86, 33);
            this.btnSair.TabIndex = 29;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // btnDesbridamento
            // 
            this.btnDesbridamento.BackColor = System.Drawing.Color.Red;
            this.btnDesbridamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDesbridamento.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDesbridamento.ForeColor = System.Drawing.Color.White;
            this.btnDesbridamento.Location = new System.Drawing.Point(463, -2);
            this.btnDesbridamento.Name = "btnDesbridamento";
            this.btnDesbridamento.Size = new System.Drawing.Size(142, 33);
            this.btnDesbridamento.TabIndex = 28;
            this.btnDesbridamento.Text = "Desbridamento";
            this.btnDesbridamento.UseVisualStyleBackColor = false;
            this.btnDesbridamento.Click += new System.EventHandler(this.BtnDesbridamento_Click);
            // 
            // btnLesao
            // 
            this.btnLesao.BackColor = System.Drawing.Color.Red;
            this.btnLesao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLesao.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLesao.ForeColor = System.Drawing.Color.White;
            this.btnLesao.Location = new System.Drawing.Point(299, -2);
            this.btnLesao.Name = "btnLesao";
            this.btnLesao.Size = new System.Drawing.Size(168, 33);
            this.btnLesao.TabIndex = 27;
            this.btnLesao.Text = "Lesão por pressão";
            this.btnLesao.UseVisualStyleBackColor = false;
            this.btnLesao.Click += new System.EventHandler(this.BtnLesao_Click);
            // 
            // btnNeuropatia
            // 
            this.btnNeuropatia.BackColor = System.Drawing.Color.Red;
            this.btnNeuropatia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNeuropatia.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNeuropatia.ForeColor = System.Drawing.Color.White;
            this.btnNeuropatia.Location = new System.Drawing.Point(178, -2);
            this.btnNeuropatia.Name = "btnNeuropatia";
            this.btnNeuropatia.Size = new System.Drawing.Size(124, 33);
            this.btnNeuropatia.TabIndex = 26;
            this.btnNeuropatia.Text = "Neuropatia";
            this.btnNeuropatia.UseVisualStyleBackColor = false;
            this.btnNeuropatia.Click += new System.EventHandler(this.BtnNeuropatia_Click);
            // 
            // btnEstomia
            // 
            this.btnEstomia.BackColor = System.Drawing.Color.Red;
            this.btnEstomia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEstomia.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEstomia.ForeColor = System.Drawing.Color.White;
            this.btnEstomia.Location = new System.Drawing.Point(92, -2);
            this.btnEstomia.Name = "btnEstomia";
            this.btnEstomia.Size = new System.Drawing.Size(97, 33);
            this.btnEstomia.TabIndex = 25;
            this.btnEstomia.Text = "Estomia";
            this.btnEstomia.UseVisualStyleBackColor = false;
            this.btnEstomia.Click += new System.EventHandler(this.BtnEstomia_Click);
            // 
            // btnInicio
            // 
            this.btnInicio.BackColor = System.Drawing.Color.Red;
            this.btnInicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInicio.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInicio.ForeColor = System.Drawing.Color.White;
            this.btnInicio.Location = new System.Drawing.Point(-1, -2);
            this.btnInicio.Name = "btnInicio";
            this.btnInicio.Size = new System.Drawing.Size(94, 33);
            this.btnInicio.TabIndex = 24;
            this.btnInicio.Text = "Início";
            this.btnInicio.UseVisualStyleBackColor = false;
            this.btnInicio.Click += new System.EventHandler(this.BtnInicio_Click);
            // 
            // tbTexto
            // 
            this.tbTexto.BackColor = System.Drawing.Color.Red;
            this.tbTexto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbTexto.ForeColor = System.Drawing.Color.White;
            this.tbTexto.Location = new System.Drawing.Point(22, 119);
            this.tbTexto.Multiline = true;
            this.tbTexto.Name = "tbTexto";
            this.tbTexto.Size = new System.Drawing.Size(638, 395);
            this.tbTexto.TabIndex = 23;
            // 
            // btnMedicacoes
            // 
            this.btnMedicacoes.BackColor = System.Drawing.Color.Red;
            this.btnMedicacoes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMedicacoes.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedicacoes.ForeColor = System.Drawing.Color.White;
            this.btnMedicacoes.Location = new System.Drawing.Point(503, 60);
            this.btnMedicacoes.Name = "btnMedicacoes";
            this.btnMedicacoes.Size = new System.Drawing.Size(157, 41);
            this.btnMedicacoes.TabIndex = 22;
            this.btnMedicacoes.Text = "MEDICAÇÕES";
            this.btnMedicacoes.UseVisualStyleBackColor = false;
            // 
            // btnTratamentos
            // 
            this.btnTratamentos.BackColor = System.Drawing.Color.Red;
            this.btnTratamentos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTratamentos.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTratamentos.ForeColor = System.Drawing.Color.White;
            this.btnTratamentos.Location = new System.Drawing.Point(341, 60);
            this.btnTratamentos.Name = "btnTratamentos";
            this.btnTratamentos.Size = new System.Drawing.Size(157, 41);
            this.btnTratamentos.TabIndex = 21;
            this.btnTratamentos.Text = "TRATAMENTOS";
            this.btnTratamentos.UseVisualStyleBackColor = false;
            // 
            // btnCausas
            // 
            this.btnCausas.BackColor = System.Drawing.Color.Red;
            this.btnCausas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCausas.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCausas.ForeColor = System.Drawing.Color.White;
            this.btnCausas.Location = new System.Drawing.Point(181, 60);
            this.btnCausas.Name = "btnCausas";
            this.btnCausas.Size = new System.Drawing.Size(157, 41);
            this.btnCausas.TabIndex = 20;
            this.btnCausas.Text = "CAUSAS";
            this.btnCausas.UseVisualStyleBackColor = false;
            // 
            // btnDefinicao
            // 
            this.btnDefinicao.BackColor = System.Drawing.Color.Red;
            this.btnDefinicao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDefinicao.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDefinicao.ForeColor = System.Drawing.Color.White;
            this.btnDefinicao.Location = new System.Drawing.Point(22, 60);
            this.btnDefinicao.Name = "btnDefinicao";
            this.btnDefinicao.Size = new System.Drawing.Size(157, 41);
            this.btnDefinicao.TabIndex = 19;
            this.btnDefinicao.Text = "O QUE É";
            this.btnDefinicao.UseVisualStyleBackColor = false;
            // 
            // TelaDesbridamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(687, 516);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnDesbridamento);
            this.Controls.Add(this.btnLesao);
            this.Controls.Add(this.btnNeuropatia);
            this.Controls.Add(this.btnEstomia);
            this.Controls.Add(this.btnInicio);
            this.Controls.Add(this.tbTexto);
            this.Controls.Add(this.btnMedicacoes);
            this.Controls.Add(this.btnTratamentos);
            this.Controls.Add(this.btnCausas);
            this.Controls.Add(this.btnDefinicao);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TelaDesbridamento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Desbridamento";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnDesbridamento;
        private System.Windows.Forms.Button btnLesao;
        private System.Windows.Forms.Button btnNeuropatia;
        private System.Windows.Forms.Button btnEstomia;
        private System.Windows.Forms.Button btnInicio;
        private System.Windows.Forms.TextBox tbTexto;
        private System.Windows.Forms.Button btnMedicacoes;
        private System.Windows.Forms.Button btnTratamentos;
        private System.Windows.Forms.Button btnCausas;
        private System.Windows.Forms.Button btnDefinicao;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Freelancer_Anne
{
    public partial class TelaNeuropatia : Form
    {
        public TelaNeuropatia()
        {
            InitializeComponent();
        }

        private void BtnInicio_Click(object sender, EventArgs e)
        {
            TelaInicial novo = new TelaInicial();
            novo.Show();
            this.Visible = false;
        }

        private void BtnEstomia_Click(object sender, EventArgs e)
        {
            TelaEstomia novo = new TelaEstomia();
            novo.Show();
            this.Visible = false;
        }

        private void BtnNeuropatia_Click(object sender, EventArgs e)
        {
            TelaNeuropatia novo = new TelaNeuropatia();
            novo.Show();
            this.Visible = false;
        }

        private void BtnLesao_Click(object sender, EventArgs e)
        {
            TelaLesao novo = new TelaLesao();
            novo.Show();
            this.Visible = false;
        }

        private void BtnDesbridamento_Click(object sender, EventArgs e)
        {
            TelaDesbridamento novo = new TelaDesbridamento();
            novo.Show();
            this.Visible = false;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            TelaLogin novo = new TelaLogin();
            novo.Show();
            this.Visible = false;
        }

        private void BtnDefinicao_Click(object sender, EventArgs e)
        {
            tbTexto.Text = "A neuropatia é uma doença que atinge o funcionamento dos nervos periféricos, podendo afetar tanto a parte de sensibilidade quanto nossa motricidade (movimentos).Os nervos periféricos são os responsáveis por encaminhar as informações do cérebro e da medula para o restante do corpo, além de receber também as informações do ambiente externo (frio, calor, dor, pressão, equilíbrio) e transmiti-las para nosso córtex cerebral."
            + Environment.NewLine + "Os sinais e sintomas da neuropatia dependem principalmente do nervo que foi lesado. Os sintomas também dependem se a lesão afeta apenas um nervo, vários nervos ou o corpo todo."
            + Environment.NewLine + "Dormência e formigamento"
            + Environment.NewLine + "Fraqueza Muscular"
            + Environment.NewLine + "Paralisia"
            + Environment.NewLine + "Extrema sensibilidade"
            + Environment.NewLine + "Intolerância ao calor"
            + Environment.NewLine + "Má digestão, azia e náuseas"
            + Environment.NewLine + "Problemas sexuais"
            + Environment.NewLine + "Problemas com a bexiga"
            + Environment.NewLine + "Dores agudas"
            + Environment.NewLine + "Problemas de coordenação"
            + Environment.NewLine + "Cãimbras";
        }

        private void BtnCausas_Click(object sender, EventArgs e)
        {
            tbTexto.Text = "Medicações"
            + Environment.NewLine + "Infecções"
            + Environment.NewLine + "Doenças autoimunes"
            + Environment.NewLine + "Doenças hereditárias"
            + Environment.NewLine + "Trauma do nervo"
            + Environment.NewLine + "Deficiência de vitaminas"
            + Environment.NewLine + "Alcoolismo"
            + Environment.NewLine + "Diabetes"
            + Environment.NewLine + "Exposição a venenos"
            + Environment.NewLine + "Uso de drogas"
            + Environment.NewLine + "Tumores";
            

        }

        private void BtnTratamentos_Click(object sender, EventArgs e)
        {
            tbTexto.Text = "A neuropatia em si não tem cura, mas é possível tratá-la fazendo com que os sintomas sejam minimizados."
            + Environment.NewLine 
            + Environment.NewLine + "Como dito anteriormente, às vezes, diminuir ou parar a quimio já é o suficiente. Mas, em outros casos, é preciso fazer o tratamento da doença de base como diabetes, insuficiência renal ou hepática, cânceres;  diminuir o uso de álcool, utilizar complexo B, oligonucleotídeos, etc."
            + Environment.NewLine 
            + Environment.NewLine + "Sendo ainda possível a utilização de “medicamentos analgésicos, anticonvulsivantes com efeitos analgésicos (como a gabapentina e a pregabalina), tratamentos tópicos como a capsaicina e antidepressivos com efeito analgésico como a duloxetina, a venlafaxina, a amitriptilina e a doxepina."
            + Environment.NewLine 
            + Environment.NewLine + "Lembrando sempre que quem decidirá qual o melhor caminho e tratamento é o neurologista que acompanha o histórico e o caso do paciente.";
        }

        private void BtnMedicacoes_Click(object sender, EventArgs e)
        {
            tbTexto.Text = "É possível a utilização de “medicamentos analgésicos, anticonvulsivantes com efeitos analgésicos (como a gabapentina e a pregabalina), tratamentos tópicos como a capsaicina e antidepressivos com efeito analgésico como a duloxetina, a venlafaxina, a amitriptilina e a doxepina."
            + Environment.NewLine
            + Environment.NewLine + "Lembrando sempre que quem decidirá qual o melhor caminho e tratamento é o neurologista que acompanha o histórico e o caso do paciente";
        }
    }
}

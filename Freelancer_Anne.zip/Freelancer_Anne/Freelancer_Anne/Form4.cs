﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Freelancer_Anne
{
    public partial class TelaEstomia : Form
    {
        internal static TelaEstomia novo;

        public TelaEstomia()
        {
            InitializeComponent();
        }

        private void BtnDefinicao_Click(object sender, EventArgs e)
        {
            tbTexto.Text = "hgdhdsj" + Environment.NewLine + "jdfhgdsjka";
            
            
               
        }

        private void BtnEstomia_Click(object sender, EventArgs e)
        {
            TelaEstomia novo = new TelaEstomia();
            novo.Show();
            this.Visible = false;
                

        }

        private void BtnInicio_Click(object sender, EventArgs e)
        {
            TelaInicial novo = new TelaInicial();
            novo.Show();
            this.Visible = false;
        }

        private void BtnNeuropatia_Click(object sender, EventArgs e)
        {
            TelaNeuropatia novo = new TelaNeuropatia();
            novo.Show();
            this.Visible = false;
        }

        private void BtnLesao_Click(object sender, EventArgs e)
        {
            TelaLesao novo = new TelaLesao();
            novo.Show();
            this.Visible = false;
        }

        private void BtnDesbridamento_Click(object sender, EventArgs e)
        {
            TelaDesbridamento novo = new TelaDesbridamento();
            novo.Show();
            this.Visible = false;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            TelaLogin novo = new TelaLogin();
            novo.Show();
            this.Visible = false;
        }
    }
}

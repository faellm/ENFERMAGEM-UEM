﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Freelancer_Anne
{
    public partial class TelaDesbridamento : Form
    {
        public TelaDesbridamento()
        {
            InitializeComponent();
        }

        private void BtnInicio_Click(object sender, EventArgs e)
        {
            TelaInicial novo = new TelaInicial();
            novo.Show();
            this.Visible = false;
        }

        private void BtnEstomia_Click(object sender, EventArgs e)
        {
            TelaEstomia novo = new TelaEstomia();
            novo.Show();
            this.Visible = false;
        }

        private void BtnNeuropatia_Click(object sender, EventArgs e)
        {
            TelaNeuropatia novo = new TelaNeuropatia();
            novo.Show();
            this.Visible = false;
        }

        private void BtnLesao_Click(object sender, EventArgs e)
        {
            TelaLesao novo = new TelaLesao();
            novo.Show();
            this.Visible = false;
        }

        private void BtnDesbridamento_Click(object sender, EventArgs e)
        {
            TelaDesbridamento novo = new TelaDesbridamento();
            novo.Show();
            this.Visible = false;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            TelaLogin novo = new TelaLogin();
            novo.Show();
            this.Visible = false;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Freelancer_Anne
{
    public partial class TelaLesao : Form
    {
        public TelaLesao()
        {
            InitializeComponent();
        }

        private void BtnInicio_Click(object sender, EventArgs e)
        {
            TelaInicial novo = new TelaInicial();
            novo.Show();
            this.Visible = false;
        }

        private void BtnEstomia_Click(object sender, EventArgs e)
        {
            TelaEstomia novo = new TelaEstomia();
            novo.Show();
            this.Visible = false;
        }

        private void BtnNeuropatia_Click(object sender, EventArgs e)
        {
            TelaNeuropatia novo = new TelaNeuropatia();
            novo.Show();
            this.Visible = false;
        }

        private void BtnLesao_Click(object sender, EventArgs e)
        {
            TelaLesao novo = new TelaLesao();
            novo.Show();
            this.Visible = false;
        }

        private void BtnDesbridamento_Click(object sender, EventArgs e)
        {
            TelaDesbridamento novo = new TelaDesbridamento();
            novo.Show();
            this.Visible = false;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            TelaLogin novo = new TelaLogin();
            novo.Show();
            this.Visible = false;
        }

        private void BtnDefinicao_Click(object sender, EventArgs e)
        {
            tbTexto.Text = "As lesões por pressão, também conhecidas escaras, são feridas que aparecem na pele de pessoas que permanecem muito tempo na mesma posição, geralmente acamadas ou com mobilidade reduzida."
            + Environment.NewLine
            + Environment.NewLine + "Essas lesões ocorrem devido à pressão constante em pontos com proeminências ósseas que ficam em contato com a superfície, como, por exemplo, a cama ou a cadeira de rodas. A ferida pode ser superficial (atingindo apenas a epiderme) ou profunda, chegando a comprometer músculos, tendões, ossos e até órgãos.";
        }

        private void BtnCausas_Click(object sender, EventArgs e)
        {
            tbTexto.Text = "A principal causa desse tipo de lesão é a falta de movimentação, já que a pressão constante no mesmo ponto diminui consideravelmente a circulação sanguínea do paciente acamado. Os locais mais comprometidos são:"
            + Environment.NewLine
            + Environment.NewLine + "Região sacral (acima do cóccix)"
            + Environment.NewLine + "Trocânteres (parte superior e lateral do fêmur)"
            + Environment.NewLine + "Maléolos (osso lateral dos pés)"
            + Environment.NewLine + "Calcanhares (devido ao constante contato com a cama)";
        }

        private void BtnTratamentos_Click(object sender, EventArgs e)
        {
            tbTexto.Text = "Para o tratamento da lesão por pressão, antes de tudo, é preciso que seja feita a avaliação do comprometimento tecidual da região afetada. Feridas profundas e com necrose (tecido morto) necessitam de limpeza rigorosa, realizada por médico ou enfermeiro estomaterapeuta. Para o sucesso do tratamento, é importante utilizar curativos que aceleram a cicatrização da pele e promovam o bem-estar do paciente."           
            + Environment.NewLine 
            + Environment.NewLine + "Mude a posição do paciente na cama, movimentando-o sequencialmente a cada 3 horas"
            + Environment.NewLine + "Hidrate a pele frequentemente"
            + Environment.NewLine + "Avalie diariamente a pele das regiões mais suscetíveis às lesões"
            + Environment.NewLine + "Para mudar a posição, nunca arraste o paciente sobre a cama"
            + Environment.NewLine + "Procure orientação profissional sobre tecnologias terapêuticas que diminuam a cronicidade das lesões";
        }
    }
}

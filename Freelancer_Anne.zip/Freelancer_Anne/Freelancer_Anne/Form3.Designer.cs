﻿namespace Freelancer_Anne
{
    partial class TelaInicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaInicial));
            this.btnInicio = new System.Windows.Forms.Button();
            this.btnEstomia = new System.Windows.Forms.Button();
            this.btnNeuropatia = new System.Windows.Forms.Button();
            this.btnLesao = new System.Windows.Forms.Button();
            this.btnDesbridamento = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnInicio
            // 
            this.btnInicio.BackColor = System.Drawing.Color.White;
            this.btnInicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInicio.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInicio.ForeColor = System.Drawing.Color.Red;
            this.btnInicio.Location = new System.Drawing.Point(0, 0);
            this.btnInicio.Name = "btnInicio";
            this.btnInicio.Size = new System.Drawing.Size(94, 42);
            this.btnInicio.TabIndex = 7;
            this.btnInicio.Text = "Início";
            this.btnInicio.UseVisualStyleBackColor = false;
            this.btnInicio.Click += new System.EventHandler(this.BtnInicio_Click);
            // 
            // btnEstomia
            // 
            this.btnEstomia.BackColor = System.Drawing.Color.White;
            this.btnEstomia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEstomia.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEstomia.ForeColor = System.Drawing.Color.Red;
            this.btnEstomia.Location = new System.Drawing.Point(93, 0);
            this.btnEstomia.Name = "btnEstomia";
            this.btnEstomia.Size = new System.Drawing.Size(97, 42);
            this.btnEstomia.TabIndex = 8;
            this.btnEstomia.Text = "Estomia";
            this.btnEstomia.UseVisualStyleBackColor = false;
            this.btnEstomia.Click += new System.EventHandler(this.BtnEstomia_Click_1);
            // 
            // btnNeuropatia
            // 
            this.btnNeuropatia.BackColor = System.Drawing.Color.White;
            this.btnNeuropatia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNeuropatia.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNeuropatia.ForeColor = System.Drawing.Color.Red;
            this.btnNeuropatia.Location = new System.Drawing.Point(179, 0);
            this.btnNeuropatia.Name = "btnNeuropatia";
            this.btnNeuropatia.Size = new System.Drawing.Size(124, 42);
            this.btnNeuropatia.TabIndex = 9;
            this.btnNeuropatia.Text = "Neuropatia";
            this.btnNeuropatia.UseVisualStyleBackColor = false;
            this.btnNeuropatia.Click += new System.EventHandler(this.BtnNeuropatia_Click_1);
            // 
            // btnLesao
            // 
            this.btnLesao.BackColor = System.Drawing.Color.White;
            this.btnLesao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLesao.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLesao.ForeColor = System.Drawing.Color.Red;
            this.btnLesao.Location = new System.Drawing.Point(300, 0);
            this.btnLesao.Name = "btnLesao";
            this.btnLesao.Size = new System.Drawing.Size(168, 42);
            this.btnLesao.TabIndex = 10;
            this.btnLesao.Text = "Lesão por pressão";
            this.btnLesao.UseVisualStyleBackColor = false;
            this.btnLesao.Click += new System.EventHandler(this.BtnLesao_Click);
            // 
            // btnDesbridamento
            // 
            this.btnDesbridamento.BackColor = System.Drawing.Color.White;
            this.btnDesbridamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDesbridamento.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDesbridamento.ForeColor = System.Drawing.Color.Red;
            this.btnDesbridamento.Location = new System.Drawing.Point(464, 0);
            this.btnDesbridamento.Name = "btnDesbridamento";
            this.btnDesbridamento.Size = new System.Drawing.Size(142, 42);
            this.btnDesbridamento.TabIndex = 11;
            this.btnDesbridamento.Text = "Desbridamento";
            this.btnDesbridamento.UseVisualStyleBackColor = false;
            this.btnDesbridamento.Click += new System.EventHandler(this.BtnDesbridamento_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.White;
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSair.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.Color.Red;
            this.btnSair.Location = new System.Drawing.Point(601, 0);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(86, 42);
            this.btnSair.TabIndex = 12;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // TelaInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(687, 516);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnDesbridamento);
            this.Controls.Add(this.btnLesao);
            this.Controls.Add(this.btnNeuropatia);
            this.Controls.Add(this.btnEstomia);
            this.Controls.Add(this.btnInicio);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TelaInicial";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Início";
            this.Load += new System.EventHandler(this.TelaInicial_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnInicio;
        private System.Windows.Forms.Button btnEstomia;
        private System.Windows.Forms.Button btnNeuropatia;
        private System.Windows.Forms.Button btnLesao;
        private System.Windows.Forms.Button btnDesbridamento;
        private System.Windows.Forms.Button btnSair;
    }
}